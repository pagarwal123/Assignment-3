﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit(object sender, EventArgs e)
        {
            Profile profile = new Profile();
            profile.date = date.Text;
            profile.hour = hor.Text;
            profile.normalizedConsmption = NormalizedConsmption.Text;
            profile.temperatre = TemperatureF.Text;
            profile.dewPoint = DewpointF.Text;
            profile.hmidity = Hmidity.Text;
            NormalizedConsmption.Visible = false;
            label1.Visible = false;

            if (dropdown.SelectedValue == "1")
            {
                string otpt = Predict.PredictValue(profile);
                string otpt1 = Predict.PredictValueRandomForest(profile);
                if (otpt != "Error")
                {
                    TextBox7.Text = otpt;
                }
                if (otpt1 != "Error")
                {
                    TextBox8.Text = otpt1;
                }

            }

            else if(dropdown.SelectedValue == "2")
            {

            }

            else
            {

            }

        }
    }
}