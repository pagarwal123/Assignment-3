﻿// This code requires the Nuget package Microsoft.AspNet.WebApi.Client to be installed.
// Instructions for doing this in Visual Studio:
// Tools -> Nuget Package Manager -> Package Manager Console
// Install-Package Microsoft.AspNet.WebApi.Client

using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace WebApplication3
{

    public class StringTable
    {
        public string[] ColumnNames { get; set; }
        public string[,] Values { get; set; }
    }

    class Predict
    {
        public static string PredictValue(Profile profile)
        {
            using (var client = new HttpClient())
            {
                var scoreRequest = new
                {

                    Inputs = new Dictionary<string, StringTable>() {
                        {
                            "input1",
                            new StringTable()
                            {
                                ColumnNames = new string[] {"date", "hour", "Normalized_Consumption", "TemperatureF", "Dew_PointF", "Humidity"},
                                Values = new string[,] {  { profile.date, profile.hour, profile.normalizedConsmption, profile.temperatre, profile.dewPoint, profile.hmidity },
                                { profile.date, profile.hour, profile.normalizedConsmption, profile.temperatre, profile.dewPoint, profile.hmidity },  }
                            }
                        },
                    },
                    GlobalParameters = new Dictionary<string, string>()
                    {
                    }
                };
                const string apiKey = "VoWGR7XQlQvhB0j3j6Mf7hwjQNpcoJ7ad48ht6NEKuvCfIpq8wDYgQlt4xr6mOoux13FX/CFasEPhoxJrWoIAg==";
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

                client.BaseAddress = new Uri("https://ussouthcentral.services.azureml.net/workspaces/1a8705b1226046e6811e3be5b1c8365d/services/2442c65c5dba44b4b8e4501569db5ad8/execute?api-version=2.0&details=true");


                HttpResponseMessage response = client.PostAsJsonAsync("", scoreRequest).Result;

                if (response.IsSuccessStatusCode)
                {
                    string jsonDocument = response.Content.ReadAsStringAsync().Result;

                    var responseBody = JsonConvert.DeserializeObject<RRSResponseObject>(jsonDocument);
                    return responseBody.Results.output1.value.Values[0][0];
                }
                else
                {
                    return "Error";
                }
            }
        }

        public static string PredictValueRandomForest(Profile profile)
        {
            using (var client = new HttpClient())
            {
                var scoreRequest = new
                {

                    Inputs = new Dictionary<string, StringTable>() {
                        {
                            "input1",
                            new StringTable()
                            {
                                ColumnNames = new string[] {"date", "hour", "Normalized_Consumption", "TemperatureF", "Dew_PointF", "Humidity"},
                                Values = new string[,] {  { profile.date, profile.hour, profile.normalizedConsmption, profile.temperatre, profile.dewPoint, profile.hmidity },
                                { profile.date, profile.hour, profile.normalizedConsmption, profile.temperatre, profile.dewPoint, profile.hmidity },  }
                            }
                        },
                    },
                    GlobalParameters = new Dictionary<string, string>()
                    {
                    }
                };
                const string apiKey = "aXNEMYesgigCuatfkLr8IxOD4AuqqPqi/pHx56cFEhRkrT5OXpdYXUbfVuCLo1jBjMh6OiWsjYyFMTX6TAgT8Q==";
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

                client.BaseAddress = new Uri("https://ussouthcentral.services.azureml.net/workspaces/1a8705b1226046e6811e3be5b1c8365d/services/a50d8aff35a84610a5329f33ba261166/execute?api-version=2.0&details=true");


                HttpResponseMessage response = client.PostAsJsonAsync("", scoreRequest).Result;

                if (response.IsSuccessStatusCode)
                {
                    string jsonDocument = response.Content.ReadAsStringAsync().Result;

                    var responseBody = JsonConvert.DeserializeObject<RRSResponseObject>(jsonDocument);
                    return responseBody.Results.output1.value.Values[0][0];
                }
                else
                {
                    return "Error";
                }
            }
        }


        #region Helper Classes
        private class RRSResponseObject
        {
            public Results Results { get; set; }
        }

        private class Results
        {
            public Output1 output1 { get; set; }
        }

        private class Output1
        {
            public string type { get; set; }
            public Value value { get; set; }
        }

        private class Value
        {
            public string[] ColumnNames { get; set; }
            public string[] ColumnTypes { get; set; }
            public string[][] Values { get; set; }
        }
        #endregion

    }
}